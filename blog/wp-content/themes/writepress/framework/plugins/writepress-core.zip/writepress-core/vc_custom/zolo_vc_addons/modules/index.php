<?php 
/*Silence is Golden*/ 
